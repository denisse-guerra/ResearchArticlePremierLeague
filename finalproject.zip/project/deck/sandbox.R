# Use this file as your sandbox for playing with coding
# The following libraries may or may not be needed but are loaded regardless.

library(tidyverse)
library(here)
library(ggplot2)
library(devtools)
library(tidytuesdayR)
library(kableExtra)
library(readr)

source(here('rawdataload.csv'))

#count of how many matches each team had as a Hometeam (they all had 19 matches)
chelsea_count <- sum(rawdataload$HomeTeam == "Chelsea")
man_city_count <- sum(rawdataload$HomeTeam == "Man City")
liverpool_count <- sum(rawdataload$HomeTeam == "Liverpool")

#number of soccer teams in the dataset
num_teams <- length(unique(rawdataload$HomeTeam))

####################################################################

#Any other value that was not 'H' in the whole FTR variable
different_values <- rawdataload$FTR[rawdataload$FTR != "H"]


#create a new data frame with only the matches that Chelsea was Hometeam 
# and the Final time results where 'H'.

#This is to only know the number of matches where Hometeam won and the row they are located
# in rawdataload

#example for just one (as I was doing it manually but I got tired so I looked for the option below)
chelsea_winshome1 <- sum(rawdataload$FTR == "H" & rawdataload$HomeTeam == "Chelsea")

####################################################################


#identify all the teams there are in the dataset referencing from hometeam
teams <- unique(rawdataload$HomeTeam)

# Loop through each team and calculate their wins at home
for (team in teams) {
  assign(paste0(tolower(team), "_winshome1"), sum(rawdataload$FTR == "H" & rawdataload$HomeTeam == team))
}


#got the binomial distribution of all the teams,
#the probability they could win more than 50% of their matches as the hometeam

arsenal_home50 <- 88.14
aston_home50 <- 1.76
brentf_home50 <- 4.99
brighton_home50 <- 0.32
burnley_home50 <- 0.32
chelsea_home50 <- 23.51
crystal_home50 <- 4.99
everton_home50 <- 23.51
leeds_home50 <- 0.05
leicester_home50 <- 38.95
liverp_home50 <- 99.07
mancity_home50 <- 99.07
manu_home50 <- 38.95
newcastle_home50 <- 12.13
norwich_home50 <- 0
south_home50 <- 1.76
totten_home50 <- 88.14
watford_home50 <- 0
westham_home50 <- 23.51
wolves_home50 <- 5.18


# Create a data frame with the variables
home50 <- data.frame(
  arsenal_home50 = 88.14,
  aston_home50 = 1.76,
  brentf_home50 = 4.99,
  brighton_home50 = 0.32,
  burnley_home50 = 0.32,
  chelsea_home50 = 23.51,
  crystal_home50 = 4.99,
  everton_home50 = 23.51,
  leeds_home50 = 0.05,
  leicester_home50 = 38.95,
  liverp_home50 = 99.07,
  mancity_home50 = 99.07,
  manu_home50 = 38.95,
  newcastle_home50 = 12.13,
  norwich_home50 = 0,
  south_home50 = 1.76,
  totten_home50 = 88.14,
  watford_home50 = 0,
  westham_home50 = 23.51,
  wolves_home50 = 5.18
)



####################################################


#now the actual dataframe
chelsea_winshome <- rawdataload[rawdataload$FTR == "H" & rawdataload$HomeTeam == "Chelsea",]



