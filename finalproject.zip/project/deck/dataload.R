# This loads your GitHub TidyTuesday data in a way that will NOT get you locked
# out of the servers.

# This example uses the Bee Colony data. You'll need to replace the content
# below with the information relevant to your own dataset of choice.

# https://github.com/rfordatascience/tidytuesday/blob/master/data/2022/2022-01-11/readme.md#get-the-data-here
# will show you the code for this. Each TidyTuesday entry will have a section just
# like it. Use that to update the code below.

# First, use the code provided in the README to load the data into a dataframe.
rawdataload <- readr::read_csv('https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2023/2023-04-04/soccer21-22.csv')

# Then, write that dataframe to a local csv file.
rawdataload |>
  readr::write_csv(here::here("raw.csv"))



# After running lines 12 and 15-16, you will have a local .csv file. At this point,
# you can close this dataload.R script file and never run it again unless you
# delete the local .csv for some reason. Remember, this is a ONE TIME THING.