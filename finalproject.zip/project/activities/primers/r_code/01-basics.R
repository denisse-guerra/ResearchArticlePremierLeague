# This is an R script file. Everything in this file is considered run-able
# R code unless it is "commented" out, like these lines.
#
# You can comment lines by selecting lines and hitting Ctrl-Shift-C or
# manually adding # at any point on a line. Anything to the right of the #
# will be considered a comment.
#
# This is useful for in-line documentation, just as with any other language.
#
#
#
#
# R the calculator -------------------------------------------------------------
#
# 
# Some things to remember with R:
#
# First, R is a calculator.

2 + 2

# Put your cursor on line 18 and hit Ctrl-Enter. That will run the code on that
# line but since that line is commented, it simply runs the next uncommented line.
# Now look at the console below and you'll see the result.
#
# If you know Python, this should be familiar.
# 
# You can also try typing directly into the console. Try typing:  3 * 3
#
# You'll also notice the horizontal lines with the text in them
# like line 13. This creates sections for better organization. But be aware:
# an R script file is NOT the same as a Quarto file! More on that shortly.
#
#
# Some more things you can do, math-wise:

8 / 2

4^3

sqrt(25)

log(100)

# And, of course, you can nest them

3 * (3 + 5 * (2 / 3))

# Libraries --------------------------------------------------------------------
#
# As you're using RStudio Cloud, this workspace already has all the libraries
# you'll need pre-installed. We'll still need to call them, though. So, let's
# do double-duty here and both a) load our first library, and b) use that
# library to see just what R did in line 47.
#

library(boomer) # this is how you load a library. This will let you use
                # functions from that library without having to specific it
                # We can see an example with boom(),
                # This package can be installed with
                # devtools::install_github("moodymudskipper/boomer")

boom(3 * (3 + 5 * (2 / 3)))

# Now, if you look in your console, you'll see what the boomer package does.
# You can see how R will parse through the different steps, deciding which one
# should be done first, and then working backwards to get the correct answer.
#
# It's a handy function to know about! We could also have called the boom()
# function like this:

boomer::boom(2*2^3)

# As long as a package/library is installed, you can use the
# library::function() syntax without needing the library() statement
#
# So now that we've loaded a library, let's look at values in R
#
#
# Values ---------------------------------------------------------
#
# Let's say we wanted to save that equation from line 47 and use it again.
# We can do that by assigning it to a value, like so:

x <- 3 * (3 + 5 * (2 / 3))

# If you run that line, you'll now see a value 'x' in your Environment tab.
# You can always display a value by simply calling it, as such:

x

# And you'll see the content assigned to x show up in the console.
# Note the <- arrow to assign. This is the standard best practice for R.
# And you can do it multiple times. For example:

y <- x * 2

# We now have y, which was assigned a value of x * 2!
#
# You can use values just as you would numbers. So, we could:

x * 2 + y

# Of course, if we want to see just what that process looks like, boom()!

boom(x * 2 + y)

# Try out the boom() function on some other equations. See what breaks it!
#
#
#
# Now let's look at the next primer R script. Run the next line:

file.edit(here::here("primers", "r_code", "02-data_and_variables.R"))

