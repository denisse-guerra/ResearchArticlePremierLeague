# See how these files are named?
#
# Don't use spaces! Instead, uses dashes - and underscores _
#
# Use a dash if you want to break up the filename, and use underscores as you
# would a space.
#
# More on filename best practices later!
#
#
#
# Here's a quick look at the libraries (packages) we'll be using:

library(tidyverse)              # The core of our data manipulation
library(here)                   # Best practices for pointing to files
library(knitr)                  # For the kable() table-creation function
library(ggplot2)                # The standard viz package
library(palmerpenguins)         # An alternative to built-in datasets

# Now, start digging into the next primer. Run this line to open it:
#
# You can run a line of code by placing your cursor on that line and hitting
# Ctrl-Enter. Try it on line 26 below. It will automatically open the next
# file you should look at!

file.edit(here::here("primers", "r_code", "01-basics.R"))

