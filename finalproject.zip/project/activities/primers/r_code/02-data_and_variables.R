# We looked at values and doing basic math in R in the 01-basics script.
#
# Now let's look at the real meat of R: loading and manipulating data and
# variables!
#
# Data -------------------------------------------------------------------------
#
# First of all, there are a number of data sets already baked into R. This is
# confusing for a lot of new R users. Run the next line to see a full list:

library(help = "datasets")

# Lots, huh? You'll often see R tutorials using sets like iris and mtcars. So,
# let's take a look at one of them (return to the Files tab after!): mtcars

?mtcars

# Don't forget to switch back to the Files tab!
#
# Note that you can use a single question mark to look up a help file, whereas
# using two (??mtcars, for example) will do a help SEARCH. Useful if what you
# want to know more about doesn't seem to have its own help page.
#
# But let's just look at the data first:

mtcars

# So that just displays the entire dataframe (R-speak for table, basically).
# Be careful with this, though, since very large datasets will take a long time
# to display!
#
# 
# Next we'll start with looking at its structure. We'll use the str() function:

str(mtcars)

# This gives us a very basic look at what makes up the mtcars dataframe. It
# displays the number of observations, the number of variables, the variables,
# themselves, the variable types, and then first ten values for those
# variables. 
#
# We'll look at much better ways to explore the data in a little bit.
#
#
# Variables --------------------------------------------------------------------
#
# You can see the $ before each variable in the str(mtcars) results. This is
# the method by which you can refer to specific variables. So, the mpg variable
# within the mtcars dataset would be:

mtcars$mpg

# Running that line will display the full list of values within that variable
# as a vector. Basically, a list of numbers. (That's because it's a numerical
# variable type! More on variable types in a bit, as well.)
#
# You might be thinking, "Hey, if we could manipulate x and y, we should be able
# to do the same with variables, right?" Right!
#

mtcars$mpg * 2

# Is that useful? Probably not just like that, no. That's where functions come
# in handy. Let's look at a few that should come in handy:

x <- x * -1     # Let's make x negative
                # Tip: you can always overwrite a variable with itself like this

abs(x)          # and then take the absolute value.

sqrt(y)         # Get the square root of a number

ceiling(y / 2)  # Gets the smallest whole number (integer) larger or equal 

floor(x / 2)    # Same, but smallest whole number that's lower or equal

trunc(pi)       # Truncates the result.

round(1.22222)  # Rounds to the closest integer

#
# Of course, there are some statistically-relevant functions here, too.
# Let's create a small vector of numbers so we can try them out
# Note the c() syntax! It combines values into a vector or list.

z <- c(1, 3, 5, 7, 10)

z

mean(z)        # Get the mean

sd(z)          # Get the standard deviation

median(z)      # Get the median

range(z)       # Display the range of a vector

min(z)         # Display the minimum value within the vector, and

max(z)         # Display the maximum value.


#
# Bringing them together -------------------------------------------------------
#
# What if you wanted to quickly see the lowest mpg in the mtcars dataset?
#

min(mtcars$mpg)

#
# Easy as that! And if you wanted to save that value, you'd assign it just like
# you did with x, y, and z, before:
#

p <- min(mtcars$mpg)

p

#
# Let's load some data ---------------------------------------------------------
#
# Remember, you can assign the built-in data to a dataframe within the
# environment and manipulate it, saving those changes.

df <- mtcars

# Now we have our very own mtcars dataframe called df

df

# See? Now you can refer to df instead of mtcars, like so:

min(df$mpg)

# Want to transform some of the data within the variables? Perhaps you know all
# the mpg values in the dataframe need to be in kilometers per liter and you
# happen to know that to convert mpg to kpl is as simple as multiplying by
# 0.425 (more or less)

df$kpl <- df$mpg * 0.425

df

# And now we have a kpl variable! Neat, huh? There are much more intuitive and
# user friendly ways of doing these sorts of data manipulation, however, and
# you'll be introduced those in the tidy primer.
#
# Before we get into tidy syntax, though, let's have an introduction to
# Quarto, the thing you'll wish you'd known about when you started school.
# Run line 153!

file.edit(here::here("primers", "quarto", "quarto_primer.qmd"))
